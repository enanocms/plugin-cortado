
package com.fluendo.player;

class Dist
{
  public String revision = "(unknown)";
  public String branch = "(unknown)";

  public Dist() {
  }
}
    