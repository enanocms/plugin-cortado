
package com.fluendo.jst;

class Configure
{
  public String buildInfo = "Built on 2006-10-26 11:34:19 GMT (version 0.2.1.1) in debug mode.";

  public String buildDate = "2006-10-26 11:34:19 GMT";
  public String buildVersion = "0.2.1.1";
  public String buildType = "debug";
  public String revision = "4046 (modified)";
  public String branch = "trunk";

  public Configure() {
  }
}
    