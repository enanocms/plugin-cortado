
package com.fluendo.player;

class Configure
{
  public String buildInfo = "Built on 2008-03-05 20:48:37 GMT (version 0.2.2) in debug mode.";

  public String buildDate = "2008-03-05 20:48:37 GMT";
  public String buildVersion = "0.2.2";
  public String buildType = "debug";
  public String revision = "(unknown)";
  public String branch = "(unknown)";

  public Configure() {
  }
}
    