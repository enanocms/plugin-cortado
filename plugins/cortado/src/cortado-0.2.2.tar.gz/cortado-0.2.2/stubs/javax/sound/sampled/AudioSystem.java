package javax.sound.sampled;

public class AudioSystem {
    public static final int NOT_SPECIFIED = -1;
    private AudioSystem() {
    }
    public static Line getLine(Line.Info info)
	throws LineUnavailableException {
      return null;
    }
}
